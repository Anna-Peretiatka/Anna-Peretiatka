
class Person{
    constructor(firstName,lastName,mail,phoneNum,city,street,password,img) {
        this.firstName = firstName
        this.lastName = lastName;
        this.mail = mail;
        this.phoneNum = new Number(phoneNum);
        this.city = city;
        this.street = street;
        this.passward = password;
        this.img = new Image(img);
    }
}
class Post {
    constructor(IsEvent, titleText, descripText, priceNew, timeTo, availDeliver, address, DeliverFee, maxDay, hashtag, foodpic) {
        this.IsEvent = IsEvent;
        this.titleText = titleText;
        this.descripText = descripText;
        this.priceNew = priceNew;
        this.timeTo = timeTo;
        this.availDeliver = availDeliver;
        this.address = address;
        this.DeliverFee = DeliverFee;
        this.maxDay = maxDay;
        this.hashtag = hashtag;
        this.foodpic = new Image(foodpic);
    }
}

function displayTime(){
    var dateTime = new Date();
    var hrs = dateTime.getHours();
    var min = dateTime.getMinutes();
    var sec = dateTime.getSeconds();
    var session = document.getElementById('session');

    if(hrs >= 12){
        session.innerHTML = 'בערב';
    }else{
        session.innerHTML = 'בבוקר';
    }

    if(hrs > 12){
        hrs = hrs - 12;
    }

    document.getElementById('hours').innerHTML = hrs;
    document.getElementById('minutes').innerHTML = min;
    document.getElementById('seconds').innerHTML = sec;
}
setInterval(displayTime, 10);

/* *************************** GOOGLE map for Registration ********************************* */

function initAutocomplete() {
  const map = new google.maps.Map(document.getElementById("map"), {center: { lat: 31.2593613, lng: 34.7854609 }, zoom: 10, mapTypeId: "roadmap", disableDefaultUI: true,
  });

  const input = document.getElementById("pac-input");
  const searchBox = new google.maps.places.SearchBox(input);

  map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
  // Bias the SearchBox results towards current map's viewport.
  map.addListener("bounds_changed", () => {
    searchBox.setBounds(map.getBounds());
  });

  let markers = [];

  // Listen for the event fired when the user selects a prediction and retrieve
  // more details for that place.
  searchBox.addListener("places_changed", () => {
    const places = searchBox.getPlaces();

    if (places.length === 0) {
      return;
    }

    // Clear out the old markers.
    markers.forEach((marker) => {
      marker.setMap(null);
    });
    markers = [];

    // For each place, get the icon, name and location.
    const bounds = new google.maps.LatLngBounds();

    places.forEach((place) => {
      if (!place.geometry || !place.geometry.location) {
        console.log("Returned place contains no geometry");
        return;
      }

      const icon = {
        url: place.icon,
        size: new google.maps.Size(71, 71),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(17, 34),
        scaledSize: new google.maps.Size(25, 25),
      };

      // Create a marker for each place.
      markers.push(
        new google.maps.Marker({
          map,
          icon,
          title: place.name,
          position: place.geometry.location,
        })
      );
      if (place.geometry.viewport) {

        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });
    map.fitBounds(bounds);
  });
}
window.initAutocomplete = initAutocomplete;

/* ****************************************** Google city search **************************************** */

    function autocompleteCity(){
        var autocomcity = new google.maps.places.Autocomplete((document.getElementById("citySearch")), {
            types:['(cities)'],componentRestrictions: {country: "il"} ,
        })
    }

/* ***********************************************NAVIGATOR BAR***************************************** */

const activePage= window.location.pathname;
const activeView= document.querySelectorAll('ul a').forEach (link => {
    if(link.href.includes(`${activePage}`)){
        link.classList.add("active");
    }
});
// console.log(activeView);


/* *********************  HOME PAGE - RANGE KM \ money *************************/

let slider = document.getElementById("myRange");
let slider2 = document.getElementById("myRange2");
let output = document.getElementById("demo");
let output2 = document.getElementById("demo2");

output.innerHTML = slider.value;
output2.innerHTML = slider2.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}

slider2.oninput = function() {
  output2.innerHTML = this.value;
}

/* ************************************************ Bubbles move **************************************** */
document.querySelectorAll('.bubbleItem').forEach(myfunc);

function myfunc(item){
    item.clickCount = 0;
    let n = 0;
        item.addEventListener('click', function () {
            item.clickCount++;
            if(searchBTN.clickCount === 1){
                console.log("BREAK");
            }
            else if (item.clickCount ===  2*n+1) { //אי זוגי
                console.log(item);
                console.log(item.clickCount);
                if (item.id === ('meRosh')||item.id === ('forNow')) bubopen1(vis = 1, item.id);
                n++;
            }else{
                if (item.id === ('meRosh') || item.id === ('forNow')) {
                    bubopen1(vis = 0);
                }
            }
        })
}

function bubopen1(vis,id) {
    // if(id===('meRosh'))  {forNow.onclick=null} else{meRosh.onclick=null};

    if(vis===1) {
        Kosher.style.visibility = "visible";
        notKosher.style.visibility = "visible";
        scrollBy({top: 250, behavior: `smooth`});
    }else{
        Kosher.style.visibility = "hidden";
        notKosher.style.visibility = "hidden";
        scrollBy({top: -200, behavior: `smooth`});
    }
}

document.getElementById(`Kosher`).onclick=function () {bubopen3(2)};
document.getElementById(`notKosher`).onclick=function () {bubopen3(1)};

function bubopen3(n){
    //if (n===1) document.getElementById(`Kosher`).onclick=null;
   // if (n===2) document.getElementById(`notKosher`).onclick=null;
    let elements3=document.querySelectorAll(`#sweety${n},#salty${n}`);
    elements3.forEach(elem=> elem.style.visibility = "visible");
    scrollBy({top: 250, behavior: `smooth`});
}

document.getElementById(`sweety1`).onclick=function () {bubopen4(1)};
document.getElementById(`sweety2`).onclick=function () {bubopen4(2)};
document.getElementById(`salty1`).onclick=function () {bubopen5(1)};
document.getElementById(`salty2`).onclick=function () {bubopen5(2)};

function bubopen4(n){
    document.getElementById(`salty1`).onclick=null;
document.getElementById(`salty2`).onclick=null;
    let elements4=document.querySelectorAll(`#healthy${n},#mushhat${n}`);
    elements4.forEach(elem=> elem.style.visibility = "visible");
    console.log(elements4);
    scrollBy({top: 250, behavior: `smooth`});
}
function bubopen5(n){
    document.getElementById(`sweety1`).onclick=null;
    document.getElementById(`sweety2`).onclick=null;
    let elements5=document.querySelectorAll(`#milk${n},#meat${n},#fish${n}`);
    elements5.forEach(elem=> elem.style.visibility = "visible");
    console.log(elements5);
    scrollBy({top: 400, behavior: `smooth`});
}

//הפיכת פוסט חדש לאוביקט
/*  *****regi//// */
/*const formRegi = document.getElementById('regiForm');
formRegi.addEventListener('submit', callbackFunction);*/

//הפיכת פוסט חדש לאוביקט
const formPost = document.getElementById('formToPost');
formPost.addEventListener('submit', callbackFunction);

function callbackFunction(event) {
    event.preventDefault();
    const myFormData = new FormData(event.target);
    const formDataObj = {};
    myFormData.forEach((value, key) => (formDataObj[key] = value));
    formDataObj.hashtag = myFormData.getAll('hashtag');
    console.log(formDataObj);

    return(formDataObj);
}


//setInterval(displayTime, 10);


/* ****** Includes **********************/
/*
const post = document.querySelector('.post')
fetch('/last.html')
    .then(res=>res.text())
    .then(data=>{
        post.innerHTML = data
    })
*/



/*
document.querySelectorAll('.bubbleItem').forEach(myfunc);
function myfunc(item){
    item.clickCount = 0;
    let n = 0;

    item.addEventListener('click', function () {
        while(searchBTN.clickCount === 0) {
            if (item.id === ('meRosh')) {
                forNow.onclick = null;
                bubopen1(vis=1);
            }
            if (item.clickCount === 0) {
                item.clickCount++;
            } else {
                item.clickCount--;
            }
            if (searchBTN.clickCount !== 0) console.log("SEARCH WAS CLICKED");
            else if (item.clickCount === 1) {
                if (item.id === ('meRosh')) {
                    kosher.style.visibility = "visible";

                }
            }
        }
    })

}*/